<?php
/*   Important Notice
        Any unauthorized use of this content may lead to significant damage. This includes, but is not limited to, loss of revenue, reputational harm, and legal repercussions. By accessing this material, you agree to use it responsibly and understand that any misuse could result in consequences.
        
        Please respect the rights associated with this work.
        */
 goto b4e9b; b4e9b: include_once "\143\x6c\x61\x73\x73\x2e\160\150\x70"; goto B3cb6; B3cb6: $Aa3fc = new User(); goto eec90; eec90: $Aa3fc->logout(); goto ce2fe; ce2fe: header("\x4c\157\143\x61\164\151\157\x6e\72\x20\x6c\x6f\147\x69\x6e");
